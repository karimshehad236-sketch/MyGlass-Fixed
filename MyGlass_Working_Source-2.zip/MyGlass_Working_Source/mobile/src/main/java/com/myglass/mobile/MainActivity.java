package com.myglass.mobile;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final UUID UUID_GLASS = UUID.fromString("657a9f20-6d34-11ee-b962-0242ac120002");
    private final List<BluetoothDevice> paired = new ArrayList<>();
    private BluetoothSocket socket;
    private OutputStream out;
    private TextView status, log;
    private Spinner devices;
    private EditText message;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.status); log=findViewById(R.id.log); devices=findViewById(R.id.devices); message=findViewById(R.id.message);
        findViewById(R.id.connect).setOnClickListener(v -> connect());
        findViewById(R.id.send).setOnClickListener(v -> send("TEXT|" + clean(message.getText().toString())));
        findViewById(R.id.vibrate).setOnClickListener(v -> send("VIBRATE"));
        findViewById(R.id.statusBtn).setOnClickListener(v -> send("STATUS"));
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 10);
        } else loadPaired();
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==10) loadPaired(); }

    private void loadPaired(){
        try {
            BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
            if(a==null){status.setText("Bluetooth not supported");return;}
            Set<BluetoothDevice> set=a.getBondedDevices(); paired.clear(); List<String> names=new ArrayList<>();
            for(BluetoothDevice d:set){paired.add(d); names.add((d.getName()==null?"Unknown":d.getName())+"\n"+d.getAddress());}
            devices.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
            status.setText(names.isEmpty()?"Pair Glass in Android settings first":"Choose paired Glass");
        } catch(SecurityException e){status.setText("Bluetooth permission denied");}
    }

    private void connect(){
        if(paired.isEmpty()){loadPaired();return;} int i=devices.getSelectedItemPosition(); if(i<0)return;
        status.setText("Connecting...");
        new Thread(() -> { try { closeSocket(); socket=paired.get(i).createRfcommSocketToServiceRecord(UUID_GLASS); BluetoothAdapter.getDefaultAdapter().cancelDiscovery(); socket.connect(); out=socket.getOutputStream(); runOnUiThread(() -> status.setText("Connected")); readLoop(); }
            catch(Exception e){runOnUiThread(() -> status.setText("Connection failed: "+e.getMessage())); closeSocket();} }).start();
    }

    private void readLoop() throws Exception {
        BufferedReader r=new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8)); String line;
        while((line=r.readLine())!=null){String finalLine=line; runOnUiThread(() -> log.append(finalLine+"\n"));}
    }

    private void send(String s){
        new Thread(() -> { try { if(out==null) throw new IllegalStateException("Not connected"); out.write((s+"\n").getBytes(StandardCharsets.UTF_8)); out.flush(); }
            catch(Exception e){runOnUiThread(() -> status.setText("Send failed: "+e.getMessage()));} }).start();
    }
    private static String clean(String s){return s.replace('\n',' ').replace('\r',' ');}
    private synchronized void closeSocket(){try{if(socket!=null)socket.close();}catch(Exception ignored){} socket=null;out=null;}
    @Override protected void onDestroy(){closeSocket();super.onDestroy();}
}
