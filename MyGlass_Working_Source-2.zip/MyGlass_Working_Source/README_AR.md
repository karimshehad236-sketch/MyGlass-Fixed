# MyGlass Working

مشروع بسيط قابل للبناء يربط هاتف Android بنظارة Google Glass Explorer Edition عبر Bluetooth Classic.

## الموجود الآن
- عرض رسالة من الهاتف على النظارة.
- اهتزاز النظارة.
- قراءة حالة الاتصال ونسبة البطارية.
- اتصال ثنائي الاتجاه عبر RFCOMM.

## البناء على GitHub
ارفع **كل محتويات هذا المجلد** إلى مستودع GitHub. سيبدأ Actions تلقائيًا. عند نجاحه نزّل Artifact باسم `MyGlass-Working-APKs`.

## التثبيت
- `MyGlass-Mobile.apk` على الهاتف.
- `MyGlass-GlassXE.apk` على النظارة عبر ADB.

هذا أساس شغال وليس نسخة حرفية من خدمات MyGlass القديمة المتوقفة.
