package com.myglass.glass;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final UUID UUID_GLASS=UUID.fromString("657a9f20-6d34-11ee-b962-0242ac120002");
    private TextView text; private volatile boolean running=true; private BluetoothServerSocket server; private BluetoothSocket socket; private OutputStream out;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);text=findViewById(R.id.text);new Thread(new Runnable(){public void run(){serverLoop();}}).start();}
    private void serverLoop(){
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter(); if(a==null){show("Bluetooth unavailable");return;}
        while(running){try{show("Waiting for phone...");server=a.listenUsingRfcommWithServiceRecord("MyGlass",UUID_GLASS);socket=server.accept();server.close();server=null;out=socket.getOutputStream();send("CONNECTED|Google Glass");show("Phone connected");readLoop();}
        catch(Exception e){if(running)show("Disconnected. Waiting...");closeAll();try{Thread.sleep(1000);}catch(Exception ignored){}}}
    }
    private void readLoop() throws Exception {BufferedReader r=new BufferedReader(new InputStreamReader(socket.getInputStream(), Charset.forName("UTF-8")));String line;while(running&&(line=r.readLine())!=null)handle(line);}
    private void handle(String line){
        if(line.startsWith("TEXT|")){show(line.substring(5));send("OK|TEXT");}
        else if(line.equals("VIBRATE")){Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);if(v!=null)v.vibrate(350);send("OK|VIBRATE");}
        else if(line.equals("STATUS")){BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);int level=android.os.Build.VERSION.SDK_INT>=21?bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY):-1;send("STATUS|battery="+level+";connected=true");}
        else if(line.equals("PING"))send("PONG"); else send("ERROR|Unknown command");
    }
    private void show(final String s){runOnUiThread(new Runnable(){public void run(){text.setText(s);}});}
    private synchronized void send(String s){try{if(out!=null){out.write((s+"\n").getBytes("UTF-8"));out.flush();}}catch(Exception ignored){}}
    private synchronized void closeAll(){try{if(socket!=null)socket.close();}catch(Exception ignored){}try{if(server!=null)server.close();}catch(Exception ignored){}socket=null;server=null;out=null;}
    @Override protected void onDestroy(){running=false;closeAll();super.onDestroy();}
}
